<x-core::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('core.name') !!}</p>
</x-core::layouts.master>
