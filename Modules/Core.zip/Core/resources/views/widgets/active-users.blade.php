<div>{{ $count }} active users</div>
