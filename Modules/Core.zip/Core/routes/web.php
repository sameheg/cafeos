<?php

use Illuminate\Support\Facades\Route;

Route::view('/login', 'core::login')->name('login');
