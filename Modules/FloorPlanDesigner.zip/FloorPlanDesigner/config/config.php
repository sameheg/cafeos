<?php

return [
    'feature_flags' => [
        'floorplan_heatmaps' => env('FF_FLOORPLAN_HEATMAPS', true),
    ],
];
