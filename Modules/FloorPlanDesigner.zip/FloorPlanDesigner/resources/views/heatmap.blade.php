<div>
    <h1>Floorplan Heatmap</h1>
</div>
